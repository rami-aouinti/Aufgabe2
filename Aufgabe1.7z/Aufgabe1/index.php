<?php


$num=1;

$Zwei='Zwei';

$Fünf='Fünf';

$Sieben='Sieben';


while ($num <= 200)
{



     if( $num < 2)

         {


           echo $num;
           
          }
     else

         {

              
           if($num % 2 == 0)

              {
                

                      echo $Zwei;


                       if( $num % 5 == 0 )

                                  {



                          echo $Fünf;

                                        if( $num % 7 == 0 )



                                        	  {


                                        	  	  echo $Sieben;

                                                     }

               	
                                     }

                      
              }
         



            elseif( $num % 5 == 0 )

              {




                    echo $Fünf;


                        if( $num % 7 == 0 )



                                        	  {


                                        	  	  echo $Sieben;

                                                     }



              	
              }




            elseif( $num % 7 == 0 )

              {





                   echo $Sieben;




              	
              }
      


            else 


            	{


echo $num;


}   








	}   

    $num++; 


echo '<br>';











}




