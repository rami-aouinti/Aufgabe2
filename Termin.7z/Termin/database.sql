
CREATE TABLE `Termin3` (
  `id` int(11) NOT NULL auto_increment,
  `TerminDatum` DATETIME,
  `Beschreibung` Text(255),
  `Created_At` TIMESTAMP NOT NULL DEFAULT NOW() ,
  `Updated_At` TIMESTAMP NOT NULL DEFAULT NOW() ON UPDATE NOW(),
  PRIMARY KEY  (`id`)
);