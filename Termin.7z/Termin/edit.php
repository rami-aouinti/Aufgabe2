<?php
// including the database connection file
include_once("config.php");

if(isset($_POST['update']))
{	

	$id = mysqli_real_escape_string($mysqli, $_POST['id']);
	
	$TerminDatum = mysqli_real_escape_string($mysqli, $_POST['TerminDatum']);
	$Beschreibung = mysqli_real_escape_string($mysqli, $_POST['Beschreibung']);
	
	// checking empty fields
	if(empty($TerminDatum) || empty($Beschreibung) ) {
				
		if(empty($TerminDatum)) {
			echo "<font color='red'>Termin field is empty.</font><br/>";
		}
		
		if(empty($Beschreibung)) {
			echo "<font color='red'>Beschreibung field is empty.</font><br/>";
		}
		
	
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	}


	 else {	
		//updating the table
		$result = mysqli_query($mysqli, "UPDATE termin3 SET TerminDatum='$TerminDatum',Beschreibung='$Beschreibung' WHERE id=$id");
		
		//redirectig to the display page. In our case, it is index.php
		header("Location: index.php");
	


	}




}



?>
<?php
//getting id from url
$id = $_GET['id'];

//selecting data associated with this particular id
$result = mysqli_query($mysqli, "SELECT * FROM termin3 WHERE id=$id");

while($res = mysqli_fetch_array($result))
{
	$TerminDatum = $res['TerminDatum'];
	$Beschreibung = $res['Beschreibung'];
	$Created_At = $res['Created_At'];
    $Updated_At = $res['Updated_At'];

}
?>
<html>
<head>	
	<title>Edit Termin</title>
</head>

<body>
	<a href="index.php">Home</a>
	<br/><br/>
	
	<form name="form1" method="post" action="edit.php">
		<table border="0">
			<tr> 
				<td>Termin Am</td>
				<td><input type="datetime-local" name="TerminDatum"></td>
			</tr>
			<tr> 
				<td>Beschreibung</td>
				<td><input type="text" name="Beschreibung"></td>
			</tr>
			<tr>
				<td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>
