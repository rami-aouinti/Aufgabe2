<html>
<head>
	<title>Add Termin</title>
</head>

<body>
<?php
//including the database connection file
include_once("config.php");

if(isset($_POST['Submit'])) {	
	$TerminDatum = mysqli_real_escape_string($mysqli, $_POST['TerminDatum']);
	$Beschreibung = mysqli_real_escape_string($mysqli, $_POST['Beschreibung']);
	
	// checking empty fields
	if(empty($TerminDatum) || empty($Beschreibung)) {
				
		if(empty($TerminDatum)) {
			echo "<font color='red'>TerminDatum field is empty.</font><br/>";
		}
		
		if(empty($Beschreibung)) {
			echo "<font color='red'>Beschreibung field is empty.</font><br/>";
		}
		
		
		
		//link to the previous page
		echo "<br/><a href='javascript:self.history.back();'>Go Back</a>";
	} else { 
		// if all the fields are filled (not empty) 
			
		//insert data to database	
		$result = mysqli_query($mysqli, "INSERT INTO termin3(TerminDatum,Beschreibung) VALUES('$TerminDatum','$Beschreibung')");
		
		//display success message
		echo "<font color='green'>Data added successfully.";
		echo "<br/><a href='index.php'>View Result</a>";
	}
}
?>
</body>
</html>
